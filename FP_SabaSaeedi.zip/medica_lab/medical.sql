-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 20, 2020 at 07:05 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medical`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `userrname` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `educ` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `adds` varchar(100) NOT NULL,
  `jobPos` varchar(100) NOT NULL,
  `exper` varchar(100) NOT NULL,
  `userid` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`userrname`, `surname`, `educ`, `phone`, `adds`, `jobPos`, `exper`, `userid`) VALUES
('saba', 'saeedi', 'MBBS', '3435455', '5', 'kabul', 'PA', 1),
('mahboba', 'sayedi', 'master', '234255', '30', 'karte3', 'cytogenetics', 3),
('walia', 'marjan', 'master', '254545', '6', 'darulman', 'cytogenetics', 4),
('milad', 'omar', 'mbbs', '87856525', '16', 'karte3', 'cyto', 7),
('emal', 'safir', 'master', '756545121', '17', 'darulaman', 'cyto', 8),
('Ahmad', 'Salih', 'MBBS', '079993442', '12', 'Kabul', 'Specialist', 10),
('moqadasa', 'lewalll', 'MBBS', '98082346', '12', 'kabul', 'specialist', 13),
('faisal', 'kamran', 'MBBS', '829324', '22', 'macrotyan', 'specialist', 14),
('mahmood', 'sadat', 'master', '38563', '12', 'jalalabad', 'cyto', 16),
('sayed', 'sayedi', 'mbbs', '29348728', '12', 'kabul', 'cyto', 17);

-- --------------------------------------------------------

--
-- Table structure for table `names`
--

CREATE TABLE `names` (
  `pnames` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `marital` varchar(100) NOT NULL,
  `age` varchar(100) NOT NULL,
  `adds` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `patienttype` varchar(100) NOT NULL,
  `patientRef` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `test` varchar(100) NOT NULL,
  `timess` varchar(100) NOT NULL,
  `dr` varchar(100) NOT NULL,
  `id` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `names`
--

INSERT INTO `names` (`pnames`, `surname`, `gender`, `marital`, `age`, `adds`, `phone`, `patienttype`, `patientRef`, `date`, `test`, `timess`, `dr`, `id`) VALUES
('Arshad', 'shinwari', 'Male', 'Single', '20', 'darulaman', '388339', 'new', 'AS', '2020-06-16', 'Test', '2020-06-19', 'saba', 1),
('noman', 'shah', 'Male', 'Single', '20', 'kabul', '202333', 'new', 'NS', '2020-06-16', 'Test', '2020-06-19', '2020-06-19', 2),
('Amina', 'Wayand', 'Female', 'Single', '26', 'Kabul', '78221', 'regular', 'AW', '2020-06-23', 'Test', '2020-06-19', 'balqis', 9),
('Nasrin', 'Shinwari', 'Female', 'Single', '21', 'kabl', '832123', 'regular', 'Nsa', '2020-06-22', 'Test', '2020-06-19', 'syed', 10),
('moqadasa', 'lewall', 'Female', 'Single', '23', 'kabul', '12334', 'new', 'ml', '2020-06-24', 'Test', '2020-06-20', 'syed', 19),
('fatma', 'qambari', 'Female', 'Single', '23', 'kabul', '83748', 'new', 'FQ', '2020-06-30', 'Test', '2020-06-20', 'mahboba', 20),
('shamim', 'sadat', 'Female', 'Married', '33', 'kabul', '87342346', 'new', 'ss', '2020-06-22', 'Test', '2020-06-20', 'milad', 21),
('suhaila', 'zaher', 'Female', 'Single', '67', 'kabul', '87346', 'regular', 'Sz', '2020-06-30', 'Test', '2020-06-20', 'saba', 22),
('haroon', 'sayed', 'Male', 'Married', '44', 'kabul', '38462', 'new', 'hs', '2020-06-30', 'Test', '2020-06-20', 'ahmad', 23);

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `id` varchar(100) NOT NULL,
  `pnames` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `marital` varchar(100) NOT NULL,
  `age` varchar(100) NOT NULL,
  `add` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `patienttype` varchar(100) NOT NULL,
  `patientRef` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `test` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `id` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `pay` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `name`, `pay`) VALUES
('1', 'Arshad', '200'),
('2', 'noman', '200'),
('3', 'sana', '200'),
('9', 'Amina', '200'),
('10', 'Nasrin', '200'),
('11', 'Arsalan', '200'),
('12', 'rahela', '200'),
('13', 'faisal', '200'),
('14', 'faisal', '200'),
('15', 'homaa', '200'),
('16', 'zuhra', '200'),
('17', 'zuhra', '200'),
('18', 'homaa', '200'),
('19', 'moqadasa', '200'),
('20', 'fatma', '200'),
('21', 'shamim', '200'),
('22', 'suhaila', '200'),
('23', 'haroon', '200');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `id` varchar(100) NOT NULL,
  `r1` varchar(100) NOT NULL,
  `r2` varchar(100) NOT NULL,
  `r3` varchar(100) NOT NULL,
  `r4` varchar(100) NOT NULL,
  `r5` varchar(100) NOT NULL,
  `r6` varchar(100) NOT NULL,
  `r7` varchar(100) NOT NULL,
  `r8` varchar(100) NOT NULL,
  `r9` varchar(100) NOT NULL,
  `r10` varchar(100) NOT NULL,
  `r11` varchar(100) NOT NULL,
  `r12` varchar(100) NOT NULL,
  `r13` varchar(100) NOT NULL,
  `r14` varchar(100) NOT NULL,
  `r15` varchar(100) NOT NULL,
  `r16` varchar(100) NOT NULL,
  `r17` varchar(100) NOT NULL,
  `r18` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`id`, `r1`, `r2`, `r3`, `r4`, `r5`, `r6`, `r7`, `r8`, `r9`, `r10`, `r11`, `r12`, `r13`, `r14`, `r15`, `r16`, `r17`, `r18`) VALUES
('1', '23', '22', '222', '1', '3', '234', '52', '22', '11', '11', '66', '1', '33', '11', '11', '21', '13', ''),
('5', '12', '12', '33', '44', '53', '13', '12', '56', '78', '87', '12', '34', '45', '56', '12', '78', '56', '56'),
('8', '11', '12', '33', '12', '2', '34', '23', '42', '11', '92', '13', '23', '11', '12', '34', '34', '21', '12'),
('9', '12', '23', '12', '11', '23', '11', '33', '21', '11', '12', '34', '12', '21', '12', '34', '32', '21', '12'),
('10', '23', '22', '11', '12', '15', '16', '23', '41', '11', '22', '12', '21', '12', '44112', '1', '11', '1', ''),
('11', '23', '4', '554', '4', '2', '34', '44', '24', '5', '24', '56', '24', '11', '13', '42', '42', '141', '435'),
('12', '3', '423', '423', '23', '23', '12', '4', '45', '77', '56', '3', '43', '24', '24', '22', '234', '24', '234'),
('14', '2', '32', '3', '34', '21', '12', '4', '34', '2', '1', '1', '34', '23', '1', '1', '1', '3', '1'),
('15', '23', '34', '3', '34', '2', '2', '4', '5', '5', '1', '4', '34', '4', '2', '1', '4', '4', '5'),
('16', '32', '1', '23', '4', '5', '5', '6', '2', '1', '4', '5', '6', '6', '2', '1', '1', '3', '1'),
('17', '12', '12', '32', '1', '2', '1', '2', '2', '4', '5', '6', '7', '2', '1', '1', '3', '4', '4'),
('18', '23', '2', '31', '21', '33', '1', '13', '11', '31', '11', '31', '11', '3', '14', '5', '1', '1', '1'),
('19', '2', '21', '1', '13', '13', '11', '31', '14', '55', '23', '121', '1', '31', '1', '3', '4', '1', '11'),
('20', '12', '12', '3', '1', '2', '34', '5', '2', '21', '6', '44', '67', '2', '122', '1', '4', '5', '6'),
('21', '23', '22', '121', '34', '13', '13', '4', '56', '76', '3', '21', '12', '56', '7', '8', '34', '12', '12'),
('22', '11', '23', '12', '13', '4', '13', '45', '6', '2', '32', '124', '46', '11', '432', '1', '14', '4', '1'),
('23', '12', '3', '1', '3', '4', '45', '5', '1', '1', '3', '4', '4', '44', '5', '345', '123', '12', '31');

-- --------------------------------------------------------

--
-- Table structure for table `userr`
--

CREATE TABLE `userr` (
  `userrname` varchar(100) NOT NULL,
  `surname` varchar(100) NOT NULL,
  `educ` varchar(100) NOT NULL,
  `phone` varchar(100) NOT NULL,
  `adds` varchar(100) NOT NULL,
  `jobPos` varchar(100) NOT NULL,
  `exper` varchar(100) NOT NULL,
  `userid` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userr`
--

INSERT INTO `userr` (`userrname`, `surname`, `educ`, `phone`, `adds`, `jobPos`, `exper`, `userid`) VALUES
('suria', 'faiqrzada', 'MLA', '34353', '12', 'kabul', 'assistant', 2),
('muzhda', 'kaviani', 'master', '923892', '12', 'kabul', 'assistant', 7);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `names`
--
ALTER TABLE `names`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `userr`
--
ALTER TABLE `userr`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `userid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `names`
--
ALTER TABLE `names`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `userr`
--
ALTER TABLE `userr`
  MODIFY `userid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
