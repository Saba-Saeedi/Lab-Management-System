package medica_lab;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import connect.connect;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import medica_lab.dashboard.tabledata;

/**
 * FXML Controller class
 *
 * @author saba_
 */
public class ReportController implements Initializable {

    @FXML
    private JFXTextField b1;
    @FXML
    private JFXTextField b2;
    @FXML
    private JFXTextField b3;
    @FXML
    private JFXTextField b4;
    @FXML
    private JFXTextField b5;
    @FXML
    private JFXTextField b6;
    @FXML
    private JFXTextField b7;
    @FXML
    private JFXTextField b8;
    @FXML
    private JFXTextField b9;
    @FXML
    private JFXTextField b10;
    @FXML
    private JFXTextField b11;
    @FXML
    private JFXTextField b12;
    @FXML
    private JFXTextField b13;
    @FXML
    private JFXTextField b14;
    @FXML
    private JFXTextField b15;
    @FXML
    private JFXTextField b16;
    @FXML
    private JFXTextField b17;
    @FXML
    private JFXTextField b18;
    @FXML
    private JFXButton create;
    @FXML
    private JFXTextField idd;

    boolean flag;
  int b;
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    connect databaseobj = new connect();

    warning obj = new warning();

    @FXML
    private void checkbtn(ActionEvent event) throws SQLException {
       
      
    }

    @FXML
    private void create(ActionEvent event) throws SQLException {

      
        
          flag = false;
        String bb = idd.getText();
        b = Integer.parseInt(bb);


        String qqq = "SELECT * FROM  names";
        PreparedStatement psst = (databaseobj.getconnection()).prepareStatement(qqq);
        ResultSet rs = psst.executeQuery(qqq);
        while (rs.next()) {
             int a = Integer.parseInt(rs.getString("id"));
            if (a==b) {
                
           
            String qq = "insert into report(id,r1,r2,r3,r4,r5,r6,r7,r8,r9,r10,r11,r12,r13,r14,r15,r16,r17,r18)Values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

            PreparedStatement pst = (databaseobj.getconnection()).prepareStatement(qq);

            pst.setString(1, idd.getText());
            pst.setString(2, b1.getText());
            pst.setString(3, b2.getText());
            pst.setString(4, b3.getText());
            pst.setString(5, b4.getText());
            pst.setString(6, b5.getText());
            pst.setString(7, b6.getText());
            pst.setString(8, b7.getText());
            pst.setString(9, b8.getText());
            pst.setString(10, b9.getText());
            pst.setString(11, b10.getText());
            pst.setString(12, b11.getText());
            pst.setString(13, b12.getText());
            pst.setString(14, b13.getText());
            pst.setString(15, b14.getText());
            pst.setString(16, b15.getText());
            pst.setString(17, b16.getText());
            pst.setString(18, b17.getText());
            pst.setString(19, b18.getText());
            int i = pst.executeUpdate();
            if (i != 0) {
                System.out.println("added");
            } 
            else {
                System.out.println("failed to add");
            }
                flag = true;
            }

        }
        if (flag) {

        } 
        else {
            obj.error("No ID Found");
        }
   }

}
