package medica_lab;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import connect.connect;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;


public class PopupController implements Initializable {
    boolean flag;
    ResultSet rs = null;
    private Label label;

    
    
    String a;
    String fname;
    int payy;
     connect databaseobj = new connect();
    @FXML
    private Label pTNAME;
    String name;
    @FXML
    private Label pTID;
    @FXML
    private JFXTextField cash;
    @FXML
    private Label retn;
    @FXML
    private JFXButton payment;
    public void initialize(URL url, ResourceBundle rb) {
    String qq = "SELECT * FROM names ORDER BY Id DESC LIMIT 1";
    
    
        try {    
            PreparedStatement pst = (databaseobj.getconnection()).prepareStatement(qq);
           rs = pst.executeQuery(qq);
         if (rs.next()) {
             fname = rs.getString("id");
             name=rs.getString("pnames");
             
             pTNAME.setText(name);
             pTID.setText(fname);            
         }
        } 
        
        catch (SQLException ex) {
            Logger.getLogger(PopupController.class.getName()).log(Level.SEVERE, null, ex);
            
        }
                                            
    }    

    @FXML
    private void payment(ActionEvent event) throws SQLException {
           
        if(flag) {                                   
        String qq = "insert into payment(id,name,pay)Values(?,?,?)";
        PreparedStatement pst = (databaseobj.getconnection()).prepareStatement(qq);
        pst.setString(1,fname);
        pst.setString(2,name);
        pst.setString(3,"200");     
        int i = pst.executeUpdate();
        
        if (i != 0) {
            System.out.println("added");
        } else {
            System.out.println("failed to add");
        }
                                                                                                                                       
            System.out.println(payy);
            closeStage();
        }       
    }
      
    warning obj=new warning();
    
    @FXML
    private void cash(ActionEvent event) {
        
    int z=Integer.valueOf(cash.getText());     
       flag= false;
       
    if(z<300) {
        obj.error("Amount is less");        
    }
    
    else {    
        System.out.println(z);
        payy=z-200;
        retn.setText(Integer.toString(payy));
        flag=true;   
    }   
}  

     public void closeStage() {
        ((Stage) cash.getScene().getWindow()).close();
    }
    
}