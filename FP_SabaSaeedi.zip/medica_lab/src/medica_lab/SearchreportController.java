package medica_lab;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import connect.connect;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

public class SearchreportController implements Initializable {

    @FXML
    private JFXTextField EnterId;
    @FXML
    private JFXButton search;
    boolean flag;
    int b;
    @FXML
    private Label l1;
    @FXML
    private Label l2;
    @FXML
    private Label l3;
    @FXML
    private Label l4;
    @FXML
    private Label l5;
    @FXML
    private Label l6;
    @FXML
    private Label l7;
    @FXML
    private Label l8;
    @FXML
    private Label q1;
    @FXML
    private Label q2;
    @FXML
    private Label q3;
    @FXML
    private Label q4;
    @FXML
    private Label q5;
    @FXML
    private Label q6;
    @FXML
    private Label q7;
    @FXML
    private Label q8;
    @FXML
    private Label q9;
    @FXML
    private Label q10;
    @FXML
    private Label q11;
    @FXML
    private Label q12;
    @FXML
    private Label q13;
    @FXML
    private Label q14;
    @FXML
    private Label q15;
    @FXML
    private Label q16;
    @FXML
    private Label q17;
    @FXML
    private Label q18;

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }
    connect databaseobj = new connect();

    @FXML
    private void search(ActionEvent event) throws SQLException {

        String ID = EnterId.getText();
        String query = "SELECT * FROM report WHERE id='" + ID + "'";
        Statement stm = (databaseobj.getconnection()).createStatement();
        ResultSet rs = stm.executeQuery(query);
        while (rs.next()) {
            flag=true;
            
        }
        if(flag)
        {
        String quer = "SELECT * FROM names WHERE id='" + ID + "'";
        Statement st = (databaseobj.getconnection()).createStatement();
        ResultSet r = st.executeQuery(quer);
        while (r.next()) {
            l1.setText(ID);
            l2.setText(r.getString(1));
            l3.setText(r.getString(5));
            l4.setText(r.getString(3));
            l5.setText(r.getString(7));
            l6.setText(r.getString(12));
            l7.setText(r.getString(9));
            l8.setText(r.getString(13));
            
        }
        
        String queryy = "SELECT * FROM report WHERE id='" + ID + "'";
        Statement stmm = (databaseobj.getconnection()).createStatement();
        ResultSet rss = stmm.executeQuery(queryy);
        while (rss.next()) {
            q1.setText(rss.getString(2));
            q2.setText(rss.getString(3));
            q3.setText(rss.getString(4));
            q4.setText(rss.getString(5));
            q5.setText(rss.getString(6));
            q6.setText(rss.getString(7));
            q7.setText(rss.getString(8));
            q8.setText(rss.getString(9));
            q9.setText(rss.getString(10));
            q10.setText(rss.getString(11));
            q11.setText(rss.getString(12));
            q12.setText(rss.getString(13));
            q13.setText(rss.getString(14));
            q14.setText(rss.getString(15));
            q15.setText(rss.getString(16));
            q16.setText(rss.getString(17));
            q17.setText(rss.getString(18));
            q18.setText(rss.getString(19));
           
             }
        }
        
        else  {
            warning obj=new warning();
            obj.error("No Record Found");
        }
  }
}
