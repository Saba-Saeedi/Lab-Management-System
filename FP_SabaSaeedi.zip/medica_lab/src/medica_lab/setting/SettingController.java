package medica_lab.setting;

import com.jfoenix.controls.JFXTextField;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.stage.FileChooser;

public class SettingController implements Initializable {

    @FXML
    private Button export;
    @FXML
    private Button Importdata;
    @FXML
    private JFXTextField location;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
    }    

    @FXML
    private void export(ActionEvent event) {
        File file;
        String path = null;
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("All files", "*.*");

        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(extFilter);

        /* Show open file dialog to select one file. */
        file = fileChooser.showOpenDialog(null);
        if (file != null) {
            path = file.getPath();
        }

        String dbUserName = "root";// username
        String dbPassword = "";//Password

        String[] restoreCmd = new String[]{"C:/xampp/mysql/bin/mysql.exe", "--user=" + dbUserName, "--password=" + dbPassword, "-e", "source " + path};
        Process runtimProcess;
        try {
            runtimProcess = Runtime.getRuntime().exec(restoreCmd);
            int proceCom = runtimProcess.waitFor();

            if (proceCom == 0) {

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Restored Succuss");
                alert.setHeaderText("");
                alert.setContentText("Restored Succuss");
                alert.showAndWait();

            } 
            else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Restored Failed");
                alert.setHeaderText("");
                alert.setContentText("Restored Failed");
                alert.showAndWait();
            }
        } 
        catch (Exception e) {
            e.printStackTrace();
        }

        
    }

    @FXML
    private void Importdata(ActionEvent event) throws IOException, InterruptedException {
        String path;
        String dbname = "test";
        String dbuser = "root";
        String dbpass = "";
        String folderpath = location.getText() + "\\Backup test";
        path = folderpath;
        path = path.replace('\\', '/');
        path = path + "test.sql";

        Process p = null;
        String executeCmd = "";
        Runtime runtime = Runtime.getRuntime();
        p = runtime.exec("C:/xampp/mysql/bin/mysqldump.exe -u -p --add-drop-database -B test -r" + path);
        int processComplete = p.waitFor();
        if (processComplete == 0) {
            
               Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Backup Created Failed");
                alert.setHeaderText("");
                alert.setContentText("Backup Created Failed");
                alert.showAndWait();
            
        } 
        else {            
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Backup Created Succuss");
                alert.setHeaderText("");
                alert.setContentText("Backup Created Succuss");
                alert.showAndWait();
        }
       
    }
    
}
