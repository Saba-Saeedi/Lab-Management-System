package medica_lab;

import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author saba_
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private BorderPane borderpan;
    @FXML
    private JFXButton reg;
    @FXML
    private JFXButton createReport;
    @FXML
    private JFXButton getReport;
    @FXML
    private JFXButton sabaSaeed;
    
   
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            load("/medica_lab/add.fxml");
        }
        catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
    
       public void load(String a) throws IOException  {
           
        Parent root=null;
        root=FXMLLoader.load(getClass().getResource(a));
        
        borderpan.setCenter(root);
    }

    @FXML
    private void reg(ActionEvent event) throws IOException {
        load("/medica_lab/add.fxml");
    }

    @FXML
    private void createReport(ActionEvent event) throws IOException {
         load("/medica_lab/report.fxml");
    }

    @FXML
    private void getReport(ActionEvent event) throws IOException {
        
         load("/medica_lab/searchreport.fxml");
    }

    @FXML
    private void sabaSaeed(ActionEvent event) throws IOException {
        loadwidows("/medica_lab/screen1.fxml","sabaseed");
              
    }
    
    
       public void loadwidows(String w,String t) throws IOException  {
           
            Parent obj = FXMLLoader.load(getClass().getResource(w));
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle(t);
            stage.setScene(new Scene(obj));
            stage.show();
    }
    
}
