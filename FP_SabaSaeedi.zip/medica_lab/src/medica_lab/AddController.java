package medica_lab;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import connect.connect;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import org.controlsfx.control.textfield.TextFields;

/**
 * FXML Controller class
 *
 * @author saba_
 */
public class AddController implements Initializable {

    @FXML
    private JFXTextField Pname;
    @FXML
    private JFXTextField Psurname;
    @FXML
    private JFXTextField Pgender;
    @FXML
    private JFXTextField Pstatus;
    @FXML
    private JFXTextField Page;
    @FXML
    private JFXTextField P_add;
    @FXML
    private JFXTextField P_phone;
    @FXML
    private JFXTextField P_type;
    @FXML
    private JFXTextField p_refer;
     connect databaseobj = new connect();
    @FXML
    private DatePicker date;
    @FXML
    private JFXTextField test;
    @FXML
    private JFXButton registration;
    public String name;
    String[] n = {"Single", "Div", "Widowed", "Married"};
    String[] G = {"Male", "Female", "other"};
    @FXML
    private JFXTextField dr;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        TextFields.bindAutoCompletion(Pstatus, n);
        TextFields.bindAutoCompletion(Pgender, G);
        
        ArrayList<String> obj = new ArrayList<>();
        String q = "Select * from doctor";
        ResultSet rs = null;
     
        try {
            rs = databaseobj.getconnection().createStatement().executeQuery(q);
        } catch (SQLException ex) {
            Logger.getLogger(AddController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        Boolean flag = false;
      
        try {
            while (rs.next()) {
                
                obj.add(rs.getString("userrname"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(AddController.class.getName()).log(Level.SEVERE, null, ex);
        }
            
             TextFields.bindAutoCompletion(dr, obj);
        

    }

    @FXML
    private void registration(ActionEvent event) throws IOException, SQLException {

        String P_name = Pname.getText();
        String P_surname = Psurname.getText();
        String P_gender = Pgender.getText();
        String P_status = Pstatus.getText();
        String P_age = Page.getText();
        String p_add = P_add.getText();
        String p_phone = P_phone.getText();
        String P_refer = p_refer.getText();
        String p_type = P_type.getText();
        String p_Test = test.getText();
        LocalDate a = date.getValue();
        String drs=dr.getText();
        String d = a.toString();

        warning obj = new warning();


            int b = 0;
            LocalDate today = LocalDate.now();
            LocalDate date=LocalDate.now();
            String todatyDate=date.toString();
            System.out.println(today.toString());
            System.out.println("hello");
      
            
            String qq = "insert into names(pnames,surname,gender,marital,age,adds,phone,patienttype,patientRef,date,test,timess,dr)Values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement pst = (databaseobj.getconnection()).prepareStatement(qq);
            pst.setString(1, P_name);
            pst.setString(2, P_surname);
            pst.setString(3, P_gender);
            pst.setString(4, P_status);
            pst.setString(5, P_age);
            pst.setString(6, p_add);
            pst.setString(7, p_phone);
            pst.setString(8, p_type);
            pst.setString(9, P_refer);
            pst.setString(10, d);
            pst.setString(11, p_Test);
            pst.setString(12, todatyDate);
            pst.setString(13, drs);

            
            
            int i = pst.executeUpdate();
            if (i != 0) {
                System.out.println("added");
            } 
            else {
                System.out.println("failed to add");
            }
            
            loadwidows("/medica_lab/Popup.fxml", "payment");     
    }

    public void loadwidows(String w, String t) throws IOException {
        Parent obj = FXMLLoader.load(getClass().getResource(w));
        Stage stage = new Stage(StageStyle.DECORATED);
        stage.setTitle(t);
        stage.setScene(new Scene(obj));
        stage.show();
    }

}
