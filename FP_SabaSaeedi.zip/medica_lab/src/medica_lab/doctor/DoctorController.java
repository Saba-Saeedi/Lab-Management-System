package medica_lab.doctor;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import connect.connect;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import medica_lab.warning;

/**
 * FXML Controller class
 *
 * @author saba_
 */
public class DoctorController implements Initializable {

    @FXML
    private JFXTextField doctorname;
    @FXML
    private JFXTextField doctorsurname;
    @FXML
    private JFXTextField doctorEducation;
    @FXML
    private JFXTextField doctorphone;
    @FXML
    private JFXTextField doctorExpeer;
    @FXML
    private JFXButton create;
    @FXML
    private JFXTextField Doctadd;
    @FXML
    private JFXTextField docpostion;

    /**
     * Initializes the controller class.
     */
    warning obj=new warning();
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    connect databaseobj = new connect();

    @FXML
    private void create(ActionEvent event) throws SQLException {
  
        String userr = doctorname.getText();
        String usersurname = doctorsurname.getText();
        String Education = doctorEducation.getText();
        String userphone = doctorphone.getText();
        String useraddrs = Doctadd.getText();
        String Postion = docpostion.getText();
        String ex = doctorExpeer.getText();
        if (userr.isEmpty() || usersurname.isEmpty() || Education.isEmpty() || userphone.isEmpty() || useraddrs.isEmpty() || Postion.isEmpty() || useraddrs.isEmpty() || ex.isEmpty()) {
 
            obj.error("Enter All Fields");
         
            
        } 
        else {
            String qq = "insert into doctor(userrname,surname,educ,phone,adds,jobPos,exper)Values(?,?,?,?,?,?,?)";
            PreparedStatement pst = (databaseobj.getconnection()).prepareStatement(qq);
            pst.setString(1, userr);
            pst.setString(2, usersurname);
            pst.setString(3, Education);
            pst.setString(4, userphone);
            pst.setString(5, ex);
            pst.setString(6, useraddrs);
            pst.setString(7, Postion);

            int i = pst.executeUpdate();
            if (i != 0) {
                         obj.conf("Successfully done in backend");
            } 
            else {
                        obj.error("Failed To add");
            }

        }

    }
}
