package medica_lab;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author saba_
 */
public class LoginController implements Initializable {

    @FXML
    private JFXTextField admin_name;
    @FXML
    private JFXPasswordField admin_password;
    @FXML
    private JFXButton admin_login;
    @FXML
    private JFXTextField User_name;
    @FXML
    private JFXPasswordField user_password;
    @FXML
    private JFXButton User_login;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
   
    }    

    @FXML
    private void admin_login(ActionEvent event) throws IOException {
        
    String name=admin_name.getText();
    String p=admin_password.getText();
    
    if(name.isEmpty() || p.isEmpty())  {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("");
        alert.setContentText("Enter All Fields");
        alert.showAndWait();
    }
    
    else {
        if(name.equals("admin") && p.equals("5107536757"))  {
        loadwidows("/medica_lab/admin/admin.fxml","User Dash Board");
    }
    else  {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("");
        alert.setContentText("Password or Username is Wrong");
        alert.showAndWait();
      }  
    }
 }

    @FXML
    private void User_login(ActionEvent event) throws IOException {
        
    String name=User_name.getText();
    String p=user_password.getText();
    
    if(name.isEmpty() || p.isEmpty())  {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("");
        alert.setContentText("Enter All Fields");
        alert.showAndWait();
    }
    else    {
      if(name.equals("sabaSaeed") && p.equals("81797384"))  {
    
        loadwidows("FXMLDocument.fxml","User Dash Board");
    
   } 
   
      else  {
        if(name.equals("sbSayed") && p.equals("88414341"))     {
        
             loadwidows("newScreen.fxml","User Dash Board");
             }
        else   {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("");
            alert.setContentText("Password or Username is Wrong");
            alert.showAndWait();
             }
    }        
  }
            
    }
    
    public void loadwidows(String w,String t) throws IOException   {
        
            Parent obj = FXMLLoader.load(getClass().getResource(w));
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setTitle(t);
            stage.setScene(new Scene(obj));
            stage.show();
    }
}
