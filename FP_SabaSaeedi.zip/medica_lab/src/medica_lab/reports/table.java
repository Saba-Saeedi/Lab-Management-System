package medica_lab.reports;

/**
 *
 * @author saba_
 */
public class table {
   
    String id;

    public table(String id) {
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

}
