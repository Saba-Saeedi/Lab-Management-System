package medica_lab.reports;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import connect.connect;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import medica_lab.bill.BillController;

/**
 * FXML Controller class
 *
 * @author saba_
 */
public class ReportDController implements Initializable {

    @FXML
    private TableView<table> table;
    @FXML
    private TableColumn<medica_lab.bill.table, String> P_id;

    /**
     * Initializes the controller class.
     */
    connect databaseobj = new connect();
    @FXML
    private JFXTextField idd;
    @FXML
    private JFXTextField b1;
    @FXML
    private JFXTextField b2;
    @FXML
    private JFXTextField b3;
    @FXML
    private JFXTextField b4;
    @FXML
    private JFXTextField b5;
    @FXML
    private JFXTextField b6;
    @FXML
    private JFXTextField b7;
    @FXML
    private JFXTextField b8;
    @FXML
    private JFXTextField b9;
    @FXML
    private JFXTextField b10;
    @FXML
    private JFXTextField b11;
    @FXML
    private JFXTextField b12;
    @FXML
    private JFXTextField b13;
    @FXML
    private JFXTextField b14;
    @FXML
    private JFXTextField b15;
    @FXML
    private JFXTextField b16;
    @FXML
    private JFXTextField b17;
    @FXML
    private JFXTextField b18;
    @FXML
    private JFXButton create;
    @FXML
    private JFXButton search;
    String s;
    @FXML
    private JFXButton delete;

    public void initialize(URL url, ResourceBundle rb) {
        // TODO

        ObservableList<table> data = FXCollections.observableArrayList();
        String z = "SELECT * FROM  report";

        PreparedStatement pst = null;

        try {
            pst = (databaseobj.getconnection()).prepareStatement(z);
        } 
        catch (SQLException ex) {
            Logger.getLogger(BillController.class.getName()).log(Level.SEVERE, null, ex);
        }

        ResultSet rsq = null;

        try {
            rsq = pst.executeQuery(z);
        } 
        catch (SQLException ex) {
            Logger.getLogger(BillController.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            while (rsq.next()) {

                data.add(new table(rsq.getString("id")));

            }
        } 
        catch (SQLException ex) {
            Logger.getLogger(BillController.class.getName()).log(Level.SEVERE, null, ex);
        }

        P_id.setCellValueFactory(new PropertyValueFactory("id"));

        table.setItems(data);

    }

    @FXML
    private void checkbtn(ActionEvent event) {
    }

    @FXML
    private void create(ActionEvent event) throws SQLException {

        String sql = "UPDATE report SET r1=?,r2=?,r3=?,r4=?,r5=?,r6=?,r7=?,r8=?,r9=?,r10=?,r11=?,r12=?,r13=?,r14=?,r15=?,r16=?,r17=?,r18=? Where id=?";
        PreparedStatement statement = (databaseobj.getconnection()).prepareStatement(sql);
        statement.setString(1, b1.getText());
        statement.setString(2, b2.getText());
        statement.setString(3, b3.getText());
        statement.setString(4, b4.getText());
        statement.setString(5, b5.getText());
        statement.setString(6, b6.getText());
        statement.setString(7, b7.getText());
        statement.setString(8, b8.getText());
        statement.setString(9, b9.getText());
        statement.setString(10, b10.getText());
        statement.setString(11, b11.getText());
        statement.setString(12, b12.getText());
        statement.setString(13, b13.getText());
        statement.setString(14, b14.getText());
        statement.setString(15, b15.getText());
        statement.setString(16, b16.getText());
        statement.setString(17, b17.getText());
        statement.setString(18, b18.getText());
        statement.setString(19, s);

        int rowsUpdated = statement.executeUpdate();
        if (rowsUpdated > 0) {
            System.out.println("An existing user was updated successfully!");
        }

    }

    @FXML
    private void search(ActionEvent event) throws SQLException {

        s = idd.getText();
        String quer = "SELECT * FROM report WHERE id='" + s + "'";
        Statement st = (databaseobj.getconnection()).createStatement();
        ResultSet r = st.executeQuery(quer);
        while (r.next()) {

            b1.setText(r.getString(2));
            b2.setText(r.getString(3));
            b3.setText(r.getString(4));
            b4.setText(r.getString(5));
            b5.setText(r.getString(6));
            b6.setText(r.getString(7));
            b7.setText(r.getString(8));
            b8.setText(r.getString(9));
            b9.setText(r.getString(10));
            b10.setText(r.getString(11));
            b11.setText(r.getString(12));
            b12.setText(r.getString(13));
            b13.setText(r.getString(14));
            b14.setText(r.getString(15));
            b15.setText(r.getString(16));
            b16.setText(r.getString(17));
            b17.setText(r.getString(18));

        }

    }

    @FXML
    private void delete(ActionEvent event) throws SQLException {

        String query = "delete from report where id ='" + s + "'";
        PreparedStatement preparedStmt = databaseobj.getconnection().prepareStatement(query);
        preparedStmt.execute();

    }

}
