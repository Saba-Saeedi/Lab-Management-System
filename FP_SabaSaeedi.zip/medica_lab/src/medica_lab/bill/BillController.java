package medica_lab.bill;

import connect.connect;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import medica_lab.PopupController;
import medica_lab.dashboard.tabledata;

/**
 * FXML Controller class
 *
 * @author saba_
 */
public class BillController implements Initializable {

    @FXML
    private Label today;
    @FXML
    private Label lastdays;
    @FXML
    private Label total;
    @FXML
    private TableView<table> table;
    @FXML
    private TableColumn<table, String> P_id;
    @FXML
 
    private TableColumn<table, String> P_name;
    @FXML
    private TableColumn<table, String> pay;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
            int e = 0;
            
            LocalDate date = LocalDate.now();
            String tt = date.toString();
            connect databaseobj = new connect();
            int b = 0;
            String qq = "SELECT * FROM  names";
            try {
                PreparedStatement pst = (databaseobj.getconnection()).prepareStatement(qq);
                ResultSet rs = pst.executeQuery(qq);
                while (rs.next()) {
                    e++;
                    String t = rs.getString("timess");
                    if (t.equals(tt)) {
                        
                        b++;
                    }

                }
            } 
            catch (SQLException ex) {
                Logger.getLogger(PopupController.class.getName()).log(Level.SEVERE, null, ex);

            }
            
            today.setText(Integer.toString(b * 200));
            total.setText(Integer.toString(e * 200));
            
            int thirtydays = 0;
            
            for (int i = 1; i <= 30; i++) {
                
                int c = 0;
                LocalDate d = LocalDate.now();
                String p = d.minusDays(i).toString();
                
                String v = "SELECT * FROM  names";
                try {
                    PreparedStatement pst = (databaseobj.getconnection()).prepareStatement(v);
                    ResultSet rs = pst.executeQuery(v);
                    while (rs.next()) {
                        
                        String t = rs.getString("timess");
                        if (t.equals(p)) {
                            
                            c++;
                        }
                        
                    }
                    
                } catch (SQLException ex) {
                    Logger.getLogger(PopupController.class.getName()).log(Level.SEVERE, null, ex);
                    
                }
                thirtydays = thirtydays + c;
                
            }
            lastdays.setText(Integer.toString(thirtydays * 200));        
            ObservableList<table> data = FXCollections.observableArrayList();
            
            
            
            String z = "SELECT * FROM  payment";
            
            PreparedStatement pst = null;
            
            try {
                pst = (databaseobj.getconnection()).prepareStatement(z);
            } 
            catch (SQLException ex) {
                Logger.getLogger(BillController.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            ResultSet rsq = null;
            
            try {
                rsq = pst.executeQuery(z);
            } 
            catch (SQLException ex) {
                Logger.getLogger(BillController.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            try {
                while (rsq.next()) {
                    
                    data.add(new table(rsq.getString("id"), rsq.getString("name"), rsq.getString("pay")));
                    
                }
            } 
            catch (SQLException ex) {
                Logger.getLogger(BillController.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            P_id.setCellValueFactory(new PropertyValueFactory("id"));
            P_name.setCellValueFactory(new PropertyValueFactory("name"));
            pay.setCellValueFactory(new PropertyValueFactory("pay"));
            
            table.setItems(data);
        }
    }
