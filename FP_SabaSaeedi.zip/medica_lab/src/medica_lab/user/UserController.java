package medica_lab.user;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import connect.connect;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import medica_lab.warning;

/**
 * FXML Controller class
 *
 * @author saba_
 */
public class UserController implements Initializable {

    @FXML
    private JFXTextField Username;
    @FXML
    private JFXTextField UserSurname;
    @FXML
    private JFXTextField education;
    @FXML
    private JFXTextField Userphone;
    @FXML
    private JFXTextField yearOfExp;
    @FXML
    private JFXTextField user_add;
    @FXML
    private JFXButton registration;
    @FXML
    private JFXTextField position;

    /**
     * Initializes the controller class.
     */
     warning obj=new warning();
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    connect databaseobj = new connect();

    @FXML
    private void registration(ActionEvent event) throws SQLException {

        String userr = Username.getText();
        String usersurname = UserSurname.getText();
        String Education = education.getText();
        String userphone = Userphone.getText();
        String useraddrs = user_add.getText();
        String Postion = position.getText();
        String ex = yearOfExp.getText();
        if (userr.isEmpty() || usersurname.isEmpty() || Education.isEmpty() || userphone.isEmpty() || useraddrs.isEmpty() || Postion.isEmpty() || useraddrs.isEmpty() || ex.isEmpty()) {

            obj.error("Enter All Fields");
           
        } 
        else {
            String qq = "insert into userr(userrname,surname,educ,phone,adds,jobPos,exper)Values(?,?,?,?,?,?,?)";
            PreparedStatement pst = (databaseobj.getconnection()).prepareStatement(qq);
            pst.setString(1, userr);
            pst.setString(2, usersurname);
            pst.setString(3, Education);
            pst.setString(4, userphone);
            pst.setString(5, ex);
            pst.setString(6, useraddrs);
            pst.setString(7, Postion);

            int i = pst.executeUpdate();
            if (i != 0) {
                obj.conf("Successfully done in backend");
            } 
            else {
                System.out.println("failed to add");
            }

        }

    }

}
