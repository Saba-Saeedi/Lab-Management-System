package medica_lab.updateuser;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import connect.connect;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import medica_lab.bill.BillController;
import medica_lab.warning;

/**
 * FXML Controller class
 *
 * @author saba_
 */
public class UpdateController implements Initializable {

    @FXML
    private TableView<table> table;
    @FXML
    private TableColumn<table, String> P_id;
    @FXML

    private TableColumn<table, String> P_name;
    @FXML
    private JFXTextField searchtext;
    @FXML
    private JFXButton searchT;
    @FXML
    private JFXTextField doctorname;
    @FXML
    private JFXTextField doctorsurname;
    @FXML
    private JFXTextField doctorEducation;
    @FXML
    private JFXTextField doctorphone;
    String s;
    @FXML
    private JFXTextField doctorExpeer;
    @FXML
    private JFXTextField Doctadd;
    @FXML
    private JFXTextField docpostion;
    @FXML
    private JFXButton update;
    @FXML
    private JFXButton delete;

    /**
     * Initializes the controller class.
     */
    connect databaseobj = new connect();

    public void initialize(URL url, ResourceBundle rb) {

        ObservableList<table> data = FXCollections.observableArrayList();

        String z = "SELECT * FROM  userr";

        PreparedStatement pst = null;

        try {
            pst = (databaseobj.getconnection()).prepareStatement(z);
        } 
        catch (SQLException ex) {
            Logger.getLogger(BillController.class.getName()).log(Level.SEVERE, null, ex);
        }

        ResultSet rsq = null;

        try {
            rsq = pst.executeQuery(z);
        } 
        catch (SQLException ex) {
            Logger.getLogger(BillController.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            while (rsq.next()) {

                data.add(new table(rsq.getString("userid"), rsq.getString("userrname")));

            }
        } 
        catch (SQLException ex) {
            Logger.getLogger(BillController.class.getName()).log(Level.SEVERE, null, ex);
        }

        P_id.setCellValueFactory(new PropertyValueFactory("id"));
        P_name.setCellValueFactory(new PropertyValueFactory("name"));

        table.setItems(data);

        // TODO
    }

    @FXML
    private void searchT(ActionEvent event) throws SQLException {

        s = searchtext.getText();
        String quer = "SELECT * FROM userr Where userid='" + s + "'";
        Statement st = (databaseobj.getconnection()).createStatement();
        ResultSet r = st.executeQuery(quer);
        while (r.next()) {

            doctorname.setText(r.getString(1));
            doctorsurname.setText(r.getString(2));
            doctorEducation.setText(r.getString(3));
            doctorphone.setText(r.getString(4));
            doctorExpeer.setText(r.getString(5));
            Doctadd.setText(r.getString(6));
            docpostion.setText(r.getString(7));

        }
    }

    @FXML
    private void update(ActionEvent event) throws SQLException {

        String P_name = doctorname.getText();
        String P_surname = doctorsurname.getText();
        String P_gender = doctorEducation.getText();
        String P_phone = doctorphone.getText();
        String P_age = doctorExpeer.getText();
        String p_add = Doctadd.getText();
        String p_position = docpostion.getText();

        warning obj = new warning();

        connect databaseobj = new connect();

        String sql = "UPDATE userr SET userrname=?,surname=?, educ=?, phone=?,adds=?,jobPos=?,exper=? WHERE userid=?";

        PreparedStatement statement = (databaseobj.getconnection()).prepareStatement(sql);
        statement.setString(1, P_name);
        statement.setString(2, P_surname);
        statement.setString(3, P_gender);
        statement.setString(4, P_phone);
        statement.setString(5, P_age);
        statement.setString(6, p_add);
        statement.setString(7, p_position);

        statement.setString(8, s);

        int rowsUpdated = statement.executeUpdate();
        if (rowsUpdated > 0) {
            System.out.println("An existing user was updated successfully!");
        }

    }

    @FXML
    private void delete(ActionEvent event) throws SQLException {

        String query = "delete from userr where userid ='" + s + "'";
        PreparedStatement preparedStmt = databaseobj.getconnection().prepareStatement(query);
        preparedStmt.execute();

    }

}
