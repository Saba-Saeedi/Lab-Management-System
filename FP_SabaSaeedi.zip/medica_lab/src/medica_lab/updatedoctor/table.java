
package medica_lab.updatedoctor;

/**
 *
 * @author saba_
 */
public class table {
  
    String id,name,edu,post,exper;

    public table(String id, String name, String edu, String post, String exper) {
        this.id = id;
        this.name = name;
        this.edu = edu;
        this.post = post;
        this.exper = exper;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEdu() {
        return edu;
    }

    public void setEdu(String edu) {
        this.edu = edu;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public String getExper() {
        return exper;
    }

    public void setExper(String exper) {
        this.exper = exper;
    }
  
}