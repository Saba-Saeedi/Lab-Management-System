package medica_lab;

import javafx.scene.control.Alert;

/**
 *
 * @author saba_
 */
public class warning {
    
    public void error(String q)  {
       
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("");
            alert.setContentText(q);
            alert.showAndWait();
    }
   
     public void conf(String q) {
          
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Success");
            alert.setHeaderText("");
            alert.setContentText(q);
            alert.showAndWait();
    }
}
