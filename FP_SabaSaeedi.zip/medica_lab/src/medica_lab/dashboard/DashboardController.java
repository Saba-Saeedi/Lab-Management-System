package medica_lab.dashboard;

import connect.connect;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import medica_lab.PopupController;

/**
 * FXML Controller class
 *
 * @author saba_
 */
public class DashboardController implements Initializable {

    @FXML
    private Label today;
    @FXML
    private Label lastdays;

    /**
     * Initializes the controller class.
     */
    ObservableList<tabledata> data = FXCollections.observableArrayList();
    LocalDate date = LocalDate.now();
    String tt = date.toString();
    connect databaseobj = new connect();
    @FXML
    private TableView<tabledata> table;
    @FXML
    private TableColumn<tabledata, String> P_id;
    @FXML
    private TableColumn<tabledata, String> P_name;
    @FXML
    private TableColumn<tabledata, String> P_surname;
    @FXML
    private TableColumn<tabledata, String> P_gender;
    @FXML
    private TableColumn<tabledata, String> P_age;
    @FXML
    private TableColumn<tabledata, String> P_phone;
    @FXML
    private TableColumn<tabledata, String> P_address;
    @FXML
    private TableColumn<tabledata, String> P_patientR;
    @FXML
    private Label total;
  int i=0;

    @FXML
    private TableColumn<tabledata, String> P_dr;
    public void initialize(URL url, ResourceBundle rb) {


  
        int b = 0;
        String qq = "SELECT * FROM  names";
        try {
            PreparedStatement pst = (databaseobj.getconnection()).prepareStatement(qq);
            ResultSet rs = pst.executeQuery(qq);
            while (rs.next()) {
              i++;
                String t = rs.getString("timess");
                if (t.equals(tt)) {

                    data.add(new tabledata(rs.getString("id"), rs.getString("pnames"), rs.getString("surname"), rs.getString("gender"), rs.getString("age"), rs.getString("phone"), rs.getString("adds"), rs.getString("patientRef"),rs.getString("dr")));

                    b++;
                }

            }
        } 
        catch (SQLException ex) {
            Logger.getLogger(PopupController.class.getName()).log(Level.SEVERE, null, ex);

        }

        P_id.setCellValueFactory(new PropertyValueFactory("id"));
        P_name.setCellValueFactory(new PropertyValueFactory("name"));
        P_surname.setCellValueFactory(new PropertyValueFactory("surname"));
        P_gender.setCellValueFactory(new PropertyValueFactory("gender"));
        P_age.setCellValueFactory(new PropertyValueFactory("age"));
        P_phone.setCellValueFactory(new PropertyValueFactory("phone"));
        P_address.setCellValueFactory(new PropertyValueFactory("add"));
        P_patientR.setCellValueFactory(new PropertyValueFactory("patientR"));
        P_dr.setCellValueFactory(new PropertyValueFactory("dr"));
        
        table.setItems(data);

        today.setText(Integer.toString(b));

       int thirtydays = 0;
          
       for(int i=1;i<=30;i++)  {
        
        int c = 0;
        LocalDate d = LocalDate.now();
         String p=d.minusDays(i).toString();
        
        System.out.println (p);
        System.out.println ("================");
        String v = "SELECT * FROM  names";
        try {
            PreparedStatement pst = (databaseobj.getconnection()).prepareStatement(v);
            ResultSet rs = pst.executeQuery(v);
            while (rs.next()) {

                String t = rs.getString("timess");
                if (t.equals(p)) {
                    
                    c++;
                }

            }
            System.out.println(i +" day "+c);
            System.out.println("================");
        } 
        catch (SQLException ex) {
            Logger.getLogger(PopupController.class.getName()).log(Level.SEVERE, null, ex);

        }
         thirtydays=thirtydays+c;
         
           
       }
       lastdays.setText(Integer.toString(thirtydays));
       total.setText(Integer.toString(i));
 
    }

}
