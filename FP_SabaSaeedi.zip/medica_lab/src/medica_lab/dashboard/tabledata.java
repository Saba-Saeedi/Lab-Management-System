package medica_lab.dashboard;

public class tabledata {

    String id, name, surname, gender, age, phone, add, patientR,dr;

    public tabledata(String id, String name, String surname, String gender, String age, String phone, String add, String patientR,String dr) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.gender = gender;
        this.age = age;
        this.phone = phone;
        this.add = add;
        this.patientR = patientR;
        this.dr=dr;
    }

    public String getDr() {
        return dr;
    }

    public void setDr(String dr) {
        this.dr = dr;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAdd() {
        return add;
    }

    public void setAdd(String add) {
        this.add = add;
    }

    public String getPatientR() {
        return patientR;
    }

    public void setPatientR(String patientR) {
        this.patientR = patientR;
    }

}
