package medica_lab.admin;

import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.layout.BorderPane;

/**
 * FXML Controller class
 *
 * @author saba_
 */
public class AdminController implements Initializable {

    @FXML
    private JFXButton UserR;
    @FXML
    private BorderPane borderpann;
    @FXML
    private JFXButton doctor;
    @FXML
    private JFXButton patients;
    @FXML
    private JFXButton Bill;
    @FXML
    private JFXButton report;
    @FXML
    private JFXButton update;
    @FXML
    private JFXButton updatedoctor;
    @FXML
    private JFXButton updateuser;
    @FXML
    private JFXButton Setting;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            load("/medica_lab/dashboard/dashboard.fxml");
            
            // TODO
        } catch (IOException ex) {
            Logger.getLogger(AdminController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    @FXML
    private void UserR(ActionEvent event) throws IOException {
        
        load("/medica_lab/user/user.fxml");
        
        
    }
  

    @FXML
    private void doctor(ActionEvent event) throws IOException {
        
        load("/medica_lab/doctor/doctor.fxml");
    }
    
     public void load(String a) throws IOException  {
         
        Parent root=null;
        root=FXMLLoader.load(getClass().getResource(a));
        
        borderpann.setCenter(root);
    }

    @FXML
    private void patients(ActionEvent event) throws IOException {
        
        load("/medica_lab/dashboard/dashboard.fxml");
        
    }

    @FXML
    private void bill(ActionEvent event) throws IOException {
        
        load("/medica_lab/bill/bill.fxml");
   
    }

    @FXML
    private void report(ActionEvent event) throws IOException {
    
        load("/medica_lab/reports/reportD.fxml");    
     
    }

    @FXML
    private void update(ActionEvent event) throws IOException {
     
         load("/medica_lab/admin/update/update.fxml");
        
    }

    @FXML
    private void updatedoctor(ActionEvent event) throws IOException {
        
         load("/medica_lab/updatedoctor/update.fxml");
        
    }

    @FXML
    private void updateuser(ActionEvent event) throws IOException {
        
        load("/medica_lab/updateuser/update.fxml");
        
    }

    @FXML
    private void Setting(ActionEvent event) throws IOException {
        
        load("/medica_lab/setting/setting.fxml");
        
    }
    
}
