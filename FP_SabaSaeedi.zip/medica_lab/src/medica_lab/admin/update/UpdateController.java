package medica_lab.admin.update;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import connect.connect;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import medica_lab.warning;

/**
 * FXML Controller class
 *
 * @author saba_
 */
public class UpdateController implements Initializable {

    @FXML
    private JFXButton search;
    private JFXTextField Pname;
    private JFXTextField Psurname;
    @FXML
    private JFXTextField Pgender;
    @FXML
    private JFXTextField Pstatus;
    @FXML
    private JFXTextField Page;
    @FXML
    private JFXTextField P_add;
    @FXML
    private JFXTextField P_phone;
    @FXML
    private JFXTextField P_type;
    @FXML
    private JFXTextField p_refer;
    @FXML
    private JFXTextField test;
    @FXML
    private JFXTextField dr;
    @FXML
    private JFXButton registration;
    String s;
    @FXML
    private JFXTextField serachText;

    connect databaseobj = new connect();
    /**
     * Initializes the controller class.
     */
   
    @FXML
    private JFXButton delete;
    @FXML
    private JFXTextField Pname1;
    @FXML
    private JFXTextField Psurname1;

    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void search(ActionEvent event) throws SQLException {

        s = serachText.getText();
        String quer = "SELECT * FROM names WHERE id='" + s + "'";
        Statement st = (databaseobj.getconnection()).createStatement();
        ResultSet r = st.executeQuery(quer);
        while (r.next()) {

            Pname1.setText(r.getString(1));
            Psurname1.setText(r.getString(2));
            Pgender.setText(r.getString(3));
            Pstatus.setText(r.getString(4));
            Page.setText(r.getString(5));
            P_add.setText(r.getString(6));
            P_phone.setText(r.getString(7));
            P_type.setText(r.getString(8));
            p_refer.setText(r.getString(9));
            test.setText(r.getString(11));
            dr.setText(r.getString(12));

        }

    }
         

    @FXML
    private void registration(ActionEvent event) throws SQLException {

     String P_name = Pname1.getText();
        String P_surname = Psurname1.getText();
        String P_gender = Pgender.getText();
        String P_status = Pstatus.getText();
        String P_age = Page.getText();
        String p_add = P_add.getText();
        String p_phone = P_phone.getText();
        String P_refer = p_refer.getText();
        String p_type = P_type.getText();
        String p_Test = test.getText();
        String drs = dr.getText();

        warning obj = new warning();

        connect databaseobj = new connect();

        String sql = "UPDATE names SET pnames=?, surname=?, gender=?, marital=?,age=?,adds=?,phone=?,patienttype=?,patientRef=?,test=?,dr=? WHERE id=?";

        PreparedStatement statement = (databaseobj.getconnection()).prepareStatement(sql);
        statement.setString(1, P_name);
        statement.setString(2, P_surname);
        statement.setString(3, P_gender);
        statement.setString(4, P_status);
        statement.setString(5, P_age);
        statement.setString(6, p_add);
        statement.setString(7, p_phone);
        statement.setString(8, p_type);
        statement.setString(9, P_refer);
        statement.setString(10, p_Test);
        statement.setString(11, drs);
        statement.setString(12, s);

        int rowsUpdated = statement.executeUpdate();
        if (rowsUpdated > 0) {
            System.out.println("An existing user was updated successfully!");
        }

    }

    @FXML
    private void delete(ActionEvent event) throws SQLException {
        
        
        
     String query = "delete from names where id ='"+ s +"'";
      PreparedStatement preparedStmt = databaseobj.getconnection().prepareStatement(query);
      preparedStmt.execute();
     
    }

}
