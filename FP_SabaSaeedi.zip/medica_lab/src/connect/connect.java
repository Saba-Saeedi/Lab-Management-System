package connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author saba_
 */
public class connect {
    
    
    Connection con=null;
    public Connection getconnection() throws SQLException
    {
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(connect.class.getName()).log(Level.SEVERE, null, ex);
        }
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Medical", "root","");
        return con;
    }
    
    
    
    
    
    
    
    
    
}
